﻿// 02_pc_automation.sp - PC System & OS Automation Script

fn run_system_audit() {
    print("ðŸ’» Fetching PC Hardware & OS System Info...");
    let info = os.system_info();

    print("----------------------------------");
    print("OS Platform:      {info.platform} {info.os_release}");
    print("Architecture:     {info.architecture}");
    print("CPU Cores:        {info.cpu_count}");
    print("CPU Usage:        {info.cpu_usage_percent}%");
    print("RAM Usage:        {info.ram_used_gb} GB / {info.ram_total_gb} GB ({info.ram_percent}%)");
    print("Disk Free:        {info.disk_free_gb} GB / {info.disk_total_gb} GB");
    print("----------------------------------");

    // Clipboard Automation
    print("ðŸ“‹ Writing automated diagnostic to Clipboard...");
    let clip_text = "Sapphire Diagnostic: CPU {info.cpu_usage_percent}%, RAM {info.ram_percent}%";
    os.clip_write(clip_text);

    let read_back = os.clip_read();
    print("ðŸ“‹ Verified Clipboard Content: '{read_back}'");

    // Notification Trigger
    os.notify("Sapphire PC Auditor", "System Audit Completed Successfully!");
    print("ðŸ”” Triggered Desktop Toast Notification!");
}

run_system_audit();

